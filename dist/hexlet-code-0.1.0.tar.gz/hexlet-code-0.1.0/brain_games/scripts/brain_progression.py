#!/usr/bin/env python
"""STEP 8."""

from brain_games.check_count import counter_game


def brain_progression():
    """Функция запуска игры. Тут в функцию поступает way."""
    counter_game(5)  # <-


if __name__ == '__main__':
    brain_progression()