#!/usr/bin/env python
"""STEP 7."""

from brain_games.check_count import counter_game


def brain_gcd():
    """Функция запуска игры. Тут в функцию поступает way."""
    counter_game(3)  # <-


if __name__ == '__main__':
    brain_gcd()