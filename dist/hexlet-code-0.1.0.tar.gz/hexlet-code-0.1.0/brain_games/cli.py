import prompt

def wel():
    name = prompt.string('May I have your name? ')
    print("Hello, " + name + "!")