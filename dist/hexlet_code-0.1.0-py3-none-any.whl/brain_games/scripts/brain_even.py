#!/usr/bin/env python
"""STEP 5."""

from brain_games.check_count import counter_game


def brain_even():
    """Функция запуска игры. Тут в функцию поступает way."""
    counter_game(1)  # <-


if __name__ == '__main__':
    brain_even()
