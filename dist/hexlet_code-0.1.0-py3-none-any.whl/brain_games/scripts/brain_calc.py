#!/usr/bin/env python
"""STEP 6."""

from brain_games.check_count import counter_game


def brain_calc():
    """Функция запуска игры. Тут в функцию поступает way."""
    counter_game(2)  # <-


if __name__ == '__main__':
    brain_calc()
