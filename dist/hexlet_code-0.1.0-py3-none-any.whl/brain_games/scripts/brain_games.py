#!/usr/bin/env python

from brain_games.cli import wel 

def main():
    print("Welcome to the Brain Games!")
    wel()

    
if  __name__ == '__main__':
    main()

